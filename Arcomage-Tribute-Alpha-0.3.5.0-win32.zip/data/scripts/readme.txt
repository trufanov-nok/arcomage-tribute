AT provides a lua-based scripting interface to script events for cards.
