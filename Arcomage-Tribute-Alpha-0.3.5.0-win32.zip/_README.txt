This is ALPHA-quality Software. Expect bugs. Hunt them down & report them, if you can - Thank you!

Issue Tracker:
http://jira.kagemai.net/browse/ARCOMAGE

E-Mail:
felix.bruckner@gmail.com