-- credits.lua
--
-- provides fancy credits!
------------------------------------

-- bleh ble
--
-- eof
--